# BookStoreExample
A simple example of an online book store made with JSP, Bootstrap, Tomcat, Java, and MySQL.
